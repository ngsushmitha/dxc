import { ResturantService } from './resturant.service';
import { Component } from '@angular/core';
import { Resturant } from './resturant.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ResturantDemo';
  constructor(private restSrv: ResturantService) {}
  resturant: Resturant = {'resturantId': 0, 'resturantName': '', 'location': '', 'rating': 0};
  resturants: Resturant[] = [];
  isShow = true;


  saveResturant() {
    this.restSrv.saveResturant(this.resturant).subscribe(
      data => console.log(data),
      error => console.log(error)
    );
  }

  getResturant() {
    this.restSrv.getResturant(this.resturant.resturantId).subscribe(
      data => this.resturant = data,
      error => console.log(error)
    );
  }

  getResturants() {
    this.restSrv.getResturants().subscribe(
      data => this.resturants = data,
      error => console.log(error)
    );
    this.isShow = !this.isShow;
  }

  deleteResturant() {
    this.restSrv.deleteResturant(this.resturant.resturantId).subscribe(
      data => console.log(data),
      error => console.log(error)
    );
  }

  updateResturant() {
    this.restSrv.updateResturant(this.resturant).subscribe(
      data => console.log(data),
      error => console.log(error)
    );
  }
}
