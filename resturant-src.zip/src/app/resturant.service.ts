import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Resturant } from './resturant.model';

@Injectable({
  providedIn: 'root'
})
export class ResturantService {

  constructor(private http: HttpClient) { }

  saveResturant(resturant: Resturant) {
    return this.http.post<any>('http://localhost:1023/resturant', resturant);
  }

  updateResturant(resturant: Resturant) {
    return this.http.put<any>('http://localhost:1023/resturant', resturant);
  }

  getResturants() {
    return this.http.get<Resturant[]>('http://localhost:1023/resturant');
  }

  getResturant(resturantId: number) {
    return this.http.get<Resturant>(`http://localhost:1023/resturant/${resturantId}`);
  }

  deleteResturant(resturantId: number) {
    return this.http.delete<any>(`http://localhost:1023/resturant/${resturantId}`);
  }
}
