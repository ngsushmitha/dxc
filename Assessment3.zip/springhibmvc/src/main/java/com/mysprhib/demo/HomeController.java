package com.mysprhib.demo;



import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mysprhib.dao.MobileDao;
import com.mysprhib.model.Mobile;

@Controller
public class HomeController {
	
	@Autowired
	MobileDao mobileDao;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Model model) {	
		return "home";
	}
	
	@RequestMapping(value = "/backHome", method = RequestMethod.GET)
	public String home1(Model model) {	
		return "home";
	}
	
	
	@RequestMapping(value = "/saveMobile", method = RequestMethod.GET)
	public String saveMobile(@ModelAttribute Mobile mobile) {	
		mobileDao.saveMobile(mobile);
		return "home";
	}
	
	@RequestMapping(value = "/getMobiles", method = RequestMethod.GET)
	public String getMobiles(Model model) {	
		ArrayList<Mobile> mobiles = mobileDao.getMobiles();
		model.addAttribute("mobiles", mobiles);
		return "display";
	}
	
	
	 @RequestMapping(value = "/delete", method = RequestMethod.GET) 
	 public String deleteMobile() { 
		 return "delete"; 
		 }
	
	
	@RequestMapping(value = "/deleteMobile", method = RequestMethod.GET)
	public String deleteMobile(@RequestParam("id") int id) {	
		mobileDao.deleteMobileById(id);
		return "delete";
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.GET) 
	 public String updateCost() { 
		 return "update"; 
		 }
	
	@RequestMapping(value = "/updateCost", method = RequestMethod.GET)
	public String updateCostById(@RequestParam("id") int id,@RequestParam("cost") int cost) {	
		mobileDao.updateCost(id,cost);
		return "update";
	}
	
}
