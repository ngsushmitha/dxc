package com.mysprhib.dao;

import java.util.ArrayList;


import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.mysprhib.model.Mobile;

@Component
public class MobileDao {
	
	@Autowired
	SessionFactory sessionFactory;
	
	@Transactional
	public void saveMobile(Mobile mobile)
	{
		Session session = sessionFactory.getCurrentSession();
		session.save(mobile);
		
	}
	
	
	@Transactional
	public ArrayList<Mobile> getMobiles(){
		Session session=sessionFactory.openSession();
		ArrayList<Mobile> mobiles= (ArrayList<Mobile>)session.createQuery("from Mobile").list();
		return mobiles;
	}
	
	@Transactional
	public ArrayList<Integer> getMobileId(){
		Session session=sessionFactory.openSession();
		ArrayList<Integer> ids= (ArrayList<Integer>)session.createQuery("select id from Mobile").list();
		return ids;
	}
	
	@Transactional
	public void deleteMobileById(int id)
	{
		
		Session session=sessionFactory.getCurrentSession();
		Mobile mobile= getMobile(id);
		session.delete(mobile);
	}
	
	@Transactional
	public Mobile getMobile(int id)
	{
		
		Session session=sessionFactory.getCurrentSession();
		Mobile mobile=(Mobile) session.get(Mobile.class, id);
		return mobile;
	}
	
	@Transactional
	public  void updateCost(int id,int cost)
	{
	Session session=sessionFactory.getCurrentSession();
	Mobile mobile = (Mobile) session.get(Mobile.class,id);	
	mobile.setCost(cost);
	}
	
	
	

}
