import { UsermodModule } from './usermod/usermod.module';
import { GenderPipe } from './task/gender.pipe';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FooterComponent } from './footer/footer.component';
import { TaskComponent } from './task/task.component';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    TaskComponent,
    GenderPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    UsermodModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
