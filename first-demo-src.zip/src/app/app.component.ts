import { MyserService } from './myser.service';
import { Employee } from './task/task.model';
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MyFirstDemo';

//   countries = ['Canada', 'United States', 'India'];
//   states = [['Ontario', 'Montreal', 'Nova Scotia'], ['Texas', 'California', 'Ohio'], ['Karnataka', 'Goa', 'Maharashtra']];
//   country;
//   fillStates: any[];
//   constructor() {}

// fill() {
//   const index = this.countries.indexOf(this.country);
//   this.fillStates = this.states[index];
// --------------------------------------
// num1: number;
// num2: number;
// sum: number;
// childMsg;
// constructor() {

// }
// add() {
//   this.sum = this.num1 + this.num2;
// }
// --------------------------------------

// employee = new Employee();
// empId;
// empName;
// empphone;
// contactList: Array<string> = [];

// add() {
// this.employee.empId = this.empId;
// this.employee.empName = this.empName;
// if (this.contactList.length === 0) {
//   this.employee.empPhone = this.empphone;
// } else {
// this.employee.empPhone = this.contactList;
// }
// }

// public store() {
//     this.contactList.push(this.empphone);
//     this.empphone = null;
// }
// marks: number;
// mark: number;
// add() {
//   this.marks = this.mark;
// }

// counter = 5;
// constructor() {
//   const interval = setInterval(() => {
//     this.counter = this.counter - 1;
//     if (this.counter === 0) {
//       clearInterval(interval);
//       document.getElementById('2').innerHTML = 'Counter Done!!!';
//     }
//   }, 1000 );
// }
// data;
// text;
// isShow = true;


// disp() {
//   this.text = this.data;
//   document.getElementById('1').innerHTML = this.text;
// }


//   show() {
//     this.isShow = !this.isShow;
//     const str = document.getElementById('2').innerHTML.valueOf();
//     if (str === 'hide') {
//       document.getElementById('2').innerHTML = 'show';
//     } else {
//       document.getElementById('2').innerHTML = 'hide';

//     }
//   }

// constructor(private ser: MyserService) {
// ser.sermethod();
// }

fruits = ['mango', 'apple', 'orange'];
selectedFruits = [] as any;
constructor() {
this.selectedFruits = [];
 // console.log(this.fruits[0])
}
 OnChange(fruit: any, isChecked: boolean) {
   if (isChecked) {
     this.selectedFruits.push(fruit);
  console.log(fruit)
  }
    else {
      this.selectedFruits.splice(this.selectedFruits.indexOf(fruit),1);
      console.log("unchecked "+fruit);

   }
  console.log(this.selectedFruits);
 }


}


