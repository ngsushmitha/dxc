import { PipeTransform, Pipe } from '@angular/core';

@Pipe({name: 'gender'})
export class GenderPipe implements PipeTransform {
    transform(value: string, gender: string, mstatus: string) {

        if (gender.toUpperCase() === 'MALE') {
            return 'Mr ' + value;
        } else {
          if (mstatus.toUpperCase() === 'MARRIED') {
            return 'Mrs ' + value;
          } else {
            return 'Miss ' + value;
        }
      }
    }


}
