import { Component, OnInit, Input } from '@angular/core';
import { Employee } from './task.model';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {



//  @Input('employee') employee: Employee;
  // @Input('mark') marks: number;

  employees: any[];
  employee = new Employee();

constructor() {
  this.employees = this.employee.getEmployees();
}
ngOnInit() {
}

}
