export class Employee {
  // empId: number;
  // empName: string;
  // empPhone: string[];



  employees: any[];


constructor() {

this.employees = [
{empId: 1 , empName: 'raj' , empGender: 'male', mStatus: 'single'},
{empId: 2, empName: 'rajeev', empGender: 'male', mStatus: 'married'},
{empId: 3, empName: 'rajeshwari', empGender: 'female', mStatus: 'single'},
{empId: 4, empName: 'rajni', empGender: 'female', mStatus: 'married'}
];

}

getEmployees() {
    return this.employees;
}
}
