import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  // @Input("sum1") sum: number;
  // @Output() event = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }
  // sendMsg() {
  //   this.event.emit('HELLO FROM CHILD');
  // }

}
