import { FreelancerService } from './../freelancer.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
securityQuestion;
securityAnswer;
recoveryEmail;
a: boolean;
  constructor(private flserv: FreelancerService, private rout: Router) { }

  ngOnInit() {
  }

  checkAnswer() {

    localStorage.setItem('recoveryEmail', this.recoveryEmail);
    this.flserv.checkSecurityAnswer(this.recoveryEmail, this.securityAnswer).subscribe(
      data => {this.a = data;
        if (this.a === true) {
          this.rout.navigateByUrl('/changepassword');
        } else if (this.a === false) {
          alert('Security Answer provided is incorrect');
        }},
      error => console.log(error)
    );

  }

}
