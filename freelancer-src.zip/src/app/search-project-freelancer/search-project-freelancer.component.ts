import { Component, OnInit, Input } from '@angular/core';
import { PostNewProject } from '../PostNewProject.model';
import { AppliedProjects } from '../AppliedProjects.model';
import { FreelancerService } from '../freelancer.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-search-project-freelancer',
  templateUrl: './search-project-freelancer.component.html',
  styleUrls: ['./search-project-freelancer.component.css']
})
export class SearchProjectFreelancerComponent implements OnInit {
  projects: PostNewProject[];
  applyproject = new  AppliedProjects();
  current = 0;
  search: string;
  constructor(private flserv: FreelancerService, private router: ActivatedRoute) { }

  ngOnInit() {

this.router.params.subscribe(params => {
   this.search = params['test'];
  }
 );
    this.flserv.searchProjectByName(this.search).subscribe(
      data => this.projects = data,
      error => console.log(error)
    );
  }

  Apply(projectID: number, projectname: string) {
    this.applyproject.projectId = projectID;
    this.applyproject.projectName = projectname;
    this.applyproject.freelancerEmail = localStorage.getItem('email');
    this.flserv.saveAppliedProject(this.applyproject).subscribe(
      data => console.log(data),
      error => console.log(error)
    );
    alert('Applied Successfully');
  }

}
