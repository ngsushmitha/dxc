import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-freelancer-home',
  templateUrl: './freelancer-home.component.html',
  styleUrls: ['./freelancer-home.component.css']
})
export class FreelancerHomeComponent implements OnInit {

  search;
  constructor() {
   }

  ngOnInit() {}
  }
