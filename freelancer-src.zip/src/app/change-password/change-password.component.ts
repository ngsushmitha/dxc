import { FreelancerService } from './../freelancer.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
freelancerPassword;
cpassword;
errorMsg =  ' ';

  constructor(private rout: Router, private flserv: FreelancerService) { }

  ngOnInit() {
  }

  validate() {
    this.errorMsg = '';
    const userNameCheck = /^[a-zA-Z\s]+$/;
    const pattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$/;
    if (!this.freelancerPassword.match(pattern)) {
      this.errorMsg += 'Invalid password pattern ';
    }

    console.log(this.errorMsg);

    if (this.errorMsg.length > 0) {
      window.alert(this.errorMsg);
    } else {

    if (this.freelancerPassword === this.cpassword) {
    const email = localStorage.getItem('recoveryEmail');
    this.flserv.updatePassword(email, this.freelancerPassword).subscribe(
      data => console.log(data),
      error => console.log(error)
    );
    alert('Password Updated');
    this.rout.navigateByUrl('/userlogin');
  } else {
        alert('Passwords not matching');
  }
}
}
}
