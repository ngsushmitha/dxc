import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminBrowseProjectsComponent } from './admin-browse-projects.component';

describe('AdminBrowseProjectsComponent', () => {
  let component: AdminBrowseProjectsComponent;
  let fixture: ComponentFixture<AdminBrowseProjectsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminBrowseProjectsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminBrowseProjectsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
