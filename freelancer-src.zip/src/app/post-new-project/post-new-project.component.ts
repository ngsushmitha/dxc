import { PostNewProject } from './../PostNewProject.model';
import { Component, OnInit } from '@angular/core';
import { FreelancerService } from '../freelancer.service';

@Component({
  selector: 'app-post-new-project',
  templateUrl: './post-new-project.component.html',
  styleUrls: ['./post-new-project.component.css']
})
export class PostNewProjectComponent implements OnInit {
  project: PostNewProject = {	'projectId': 0,
    'projectName': '',
    'smallDescription': '',
    'projectCost': 0,
    'projectDuration': '',
    'projectStatus': ''};
  constructor(private flsrv: FreelancerService) { }

  ngOnInit() {
  }
postProject(){
  this.flsrv.saveProject(this.project).subscribe(
    data => console.log(data),
    error => console.log(error)

  );
  alert("Project posted successfully!!");
}

}
