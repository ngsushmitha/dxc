export class AwardedProjects {
  projectId: number;
  freelancerEmail: string;
  projectName: string;
  id: number;
  projectDuration: string;
  projectCost: number;
}
