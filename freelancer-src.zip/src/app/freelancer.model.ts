export class Freelancer {

  freelancerName: string;
  freelancerEmail: string;
  freelancerPhone: number;
  freelancerPassword: string;
  securityQuestion: string;
  securityAnswer: string;
  freelancerSkills: string;
  freelancerExperience: string;


}
