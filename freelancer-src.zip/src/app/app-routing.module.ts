import { AllFreelancersComponent } from './all-freelancers/all-freelancers.component';
import { SearchProjectFreelancerComponent } from './search-project-freelancer/search-project-freelancer.component';

import { FreelancerBrowseProjectsComponent } from './freelancer-browse-projects/freelancer-browse-projects.component';
import { FirstPageComponent } from './first-page/first-page.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { ProfileComponent } from './profile/profile.component';
import { AppliedProjectsComponent } from './applied-projects/applied-projects.component';
import { AwardedProjectsComponent } from './awarded-projects/awarded-projects.component';
import { FreelancerHomeComponent } from './freelancer-home/freelancer-home.component';
import { FreelancerLoginComponent } from './freelancer-login/freelancer-login.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { FreelancerRegistrationComponent } from './freelancer-registration/freelancer-registration.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { combineLatest } from 'rxjs';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminBrowseProjectsComponent } from './admin-browse-projects/admin-browse-projects.component';
import { PostNewProjectComponent } from './post-new-project/post-new-project.component';
import { SearchProjectAdminComponent } from './search-project-admin/search-project-admin.component';
import { AdminAwardedProjectsComponent } from './admin-awarded-projects/admin-awarded-projects.component';
import { ChangePasswordComponent } from './change-password/change-password.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'firstpage',
    pathMatch: 'full'
    },
  {path: 'registration', component: FreelancerRegistrationComponent},
  {path: 'adminlogin', component: AdminLoginComponent},
  {path: 'userlogin', component: FreelancerLoginComponent},
  {path: 'freelancerhome', component: FreelancerHomeComponent,
  children: [
  {path: 'freelancerhome/awardedprojects', component: AwardedProjectsComponent},
  {path: 'freelancerhome/appliedprojects', component: AppliedProjectsComponent},
  {path: 'freelancerhome/profile', component: ProfileComponent},
  {path: 'freelancerhome/browseprojects' , component: FreelancerBrowseProjectsComponent},
  {path: 'freelancerhome/searchprojectfreelancer/:test', component: SearchProjectFreelancerComponent }]
  },
  {path: 'adminhome', component: AdminHomeComponent,
  children: [
    {path: 'adminhome/postnewproject', component: PostNewProjectComponent},
    {path: 'adminhome/browseprojects', component: AdminBrowseProjectsComponent},
    {path: 'adminhome/adminawardedprojects', component: AdminAwardedProjectsComponent},
    {path: 'adminhome/allfreelancers', component: AllFreelancersComponent},
    {path: 'adminhome/searchprojectadmin/:test', component: SearchProjectAdminComponent }
  ]},
  {path: 'forgotpassword', component: ForgotPasswordComponent},
  {path: 'changepassword', component: ChangePasswordComponent},

  {path: 'firstpage', component: FirstPageComponent},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
