import { FreelancerService } from './../freelancer.service';
import { Component, OnInit } from '@angular/core';
import { PostNewProject } from '../PostNewProject.model';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-search-project-admin',
  templateUrl: './search-project-admin.component.html',
  styleUrls: ['./search-project-admin.component.css']
})
export class SearchProjectAdminComponent implements OnInit {
  projects: PostNewProject[];
  current = 0;
  search: string;
  project = new PostNewProject();

  constructor(private flserv: FreelancerService, private router: ActivatedRoute) { }

  ngOnInit() {
    this.router.params.subscribe(params => {
      this.search = params['test'];
     }
    );
   // console.log(this.search);
       this.flserv.searchProjectByName(this.search).subscribe(
         data => this.projects = data,
         error => console.log(error)
       );
  }
  close(projectId: number) {
    this.flserv.updateStatusAsClose(projectId).subscribe(
      data => console.log(data),
      error => console.log(error)
    );
    alert('Project Closed');
  }
  getProjectById(projectId: number) {
    this.flserv.getProjectById(projectId).subscribe(
      data => this.project = data,
      error => console.log(error)
    );
}

update() {
this.flserv.updateProject(this.project).subscribe(
  data => console.log(data),
  error => console.log(error)
);
alert('Project Updated');
}
}
